<?php
require_once("conecta.php");
  if( empty($_GET['utilizador']) || empty($_GET['confirmacao']) )
    die('<p>Não é possível alterar a password: dados em falta</p>');
 
  //mysqli_connect('localhost', 'root', '');  // ligar à base de dados
  //mysqli_select_db('pri2021', 'recuperacao');  // escolher a base de dados pretendida
 
  $user = mysqli_real_escape_string($_GET['utilizador']);
  $hash = mysqli_real_escape_string($_GET['confirmacao']);
 
  $q = mysqli_query("SELECT COUNT(*) FROM recuperacao WHERE utilizador = '$user' AND confirmacao = '$hash'");
 
  if( mysqli_result($q, 0, 0) == "1" ){
    // os dados estão corretos: eliminar o pedido e permitir alterar a password
    mysqli_query("DELETE FROM recuperacao WHERE utilizador = '$user' AND confirmacao = '$hash'");
 
    echo 'Sucesso! (Mostrar formulário de alteração de password aqui)';   
 
  } else {
    echo '<p>Não é possível alterar a password: dados incorretos</p>';
 
  }
 
?>