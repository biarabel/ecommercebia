<?php 
require_once("banco-adm.php");
//require_once("logica-usuario.php");
?>
<?php

$email = $_POST["email"];
$senha = $_POST["senha"];
$confsenha = $_POST["confsenha"];
$nomeusuario = $_POST["nomeusuario"];
$nomecompleto = $_POST["nomecompleto"];
$cpf = $_POST["cpf"];
$endereco = $_POST["endereco"];
$numero = $_POST["numero"];
$bairro = $_POST["bairro"];
$estado = $_POST["estado"];
$telefone = $_POST["telefone"];


if($email == "" || $senha == "" || $confsenha == "" || $nomeusuario == "" || $nomecompleto == "" ||  $cpf == ""||$endereco == "" || $numero == "" || $bairro == "" || $estado == "" || $telefone == ""){
	$_SESSION["danger"] = "Prencha todos os dados.";
	header("Location: cadastraradm.php");
}else{
	cadastraAdm($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $id);
	$_SESSION["success"] = "Administrador cadastrado com sucesso.";
	header("Location: loginadm.php");
}
die();
?>