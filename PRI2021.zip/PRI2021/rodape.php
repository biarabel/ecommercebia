	</div>
</div>
<div class="navbar navbar-inverse navbar-default navbar-fixed-bottom">
	<div class="contaniner">
		<div class="navbar-header">
		<footer>
			<p class="navbar-brand">&copy; Montaigna Chocolatier | 2021 </p>
		</footer>
		</div>
	</div>
</div>	
</body>
</html>