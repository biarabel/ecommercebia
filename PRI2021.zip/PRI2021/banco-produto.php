<?php
require_once("conecta.php");

function insereProduto($conexao, $nome, $preco, $descricao, $categoria_id, $unidademedida, $imagem){
	$nome = mysqli_real_escape_string($conexao, $nome);
	$preco = mysqli_real_escape_string($conexao, $preco);
	$descricao = mysqli_real_escape_string($conexao, $descricao);
	$unidademedida = mysqli_real_escape_string($conexao, $unidademedida);
	$imagem = mysqli_real_escape_string($conexao, $imagem);
	$query = "insert into produtos (nome, preco, descricao, categoria_id, unidademedida, imagem) values ('{$nome}', '{$preco}', '{$descricao}', '{$categoria_id}', '{$unidademedida}', '{$imagem}')";
	$resultadoDaInsercao = mysqli_query($conexao, $query);
	return $resultadoDaInsercao;

}

function buscaProduto($conexao, $id){
	$query = "select nome, preco, descricao, categoria, peso, imagem from produtos where id = {$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}

function buscaImagem($conexao, $imagem, $id){
	$query = "selec imagem from produtos where id = {$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}

function alteraProduto($conexao, $id, $nome, $preco, $descricao, $categoria_id, $unidademedida, $imagem){
	 $nome = mysqli_real_escape_string($conexao, $nome);
	 $preco = mysqli_real_escape_string($conexao, $preco);
	 $descricao = mysqli_real_escape_string($conexao, $descricao);
	 $unidademedida = mysqli_real_escape_string($conexao, $unidademedida);
	 $imagem = mysqli_real_escape_string($conexao, $imagem);
	 $query = "update produtos set nome = '{$nome}', preco = '{$preco}', descricao = '{$descricao}', categoria_id = '{$categoria_id}', unidademedida = '{$unidademedida}', imagem = '{$imagem}' where id = '{$id}'";
	 return mysqli_query($conexao, $query);
}

function removeProduto($conexao,$id){
  $query = "delete from produtos where id = {$id}";
  return mysqli_query($conexao, $query);
}
function listaProdutos($conexao){
	$produtos = array();
	$resultado = mysqli_query($conexao, "select p.*,c.nome as categoria_nome from produtos as p join categorias as c on c.id=p.categoria_id");

	while($produto = mysqli_fetch_assoc($resultado)){ 
		array_push($produtos, $produto);
	}
	return $produtos;
}

?>

