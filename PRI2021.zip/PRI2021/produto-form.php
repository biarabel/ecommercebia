<?php  
require_once("banco-categoria.php");

$produto = array("nome" => "", "preco" => "", "categoria_id" => "1", "unidademedida" => "", "imagem" => "");
$categorias = listaCategoria($conexao);

?>
	
	<form action="adiciona-produto.php" method="post">
		<table class="table">
        
            <?php require_once("produto-formulario-base.php"); ?>
            <tr>
                <td><button class="btn btn-primary btn-lg" type="submit">Cadastrar</button></td>
            </tr>
				<td><a href="menuadm.php"> Voltar ao Menu</a></td>
        </table>

	</form>
<?php require_once("rodape.php"); ?>