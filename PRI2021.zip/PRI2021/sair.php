<?php
	session_start();
	unset($_SESSION['idusuario'],$_SESSION['nomeusuario'],$_SESSION['nivelacessousuario'],$_SESSION['emailusuario'],$_SESSION['senhausuario']);
	$_SESSION['deslogado'] = "Deslogado com sucesso.";
	header("Location: index.php");
?>