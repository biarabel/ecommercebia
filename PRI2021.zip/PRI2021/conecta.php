<?php
$conexao = mysqli_connect('localhost', 'root', '', 'pri2021');

#$conexao = mysqli_connect('localhost', 'root', '', 'loja');
