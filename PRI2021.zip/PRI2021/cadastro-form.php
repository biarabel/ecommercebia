
<h1>Cadastre-se</h1>
	<form action="cadastro.php" method="post">
		<table class="table">
			<tr>
				<td>E-mail</td>
				<td><input class="form-control" type="email" name="email"></td>
			</tr>
			<tr>
				<td>Senha</td>
				<td><input class="form-control" type="password" name="senha"></td>
			</tr>
			<tr>
				<td>Confirme sua senha</td>
				<td><input class="form-control" type="password" name="confsenha"></td>
			</tr>
			<tr>
				<td>Nome de usuário</td>
				<td><input class="form-control" type="text" name="nomeusuario"></td>
			</tr>
			<tr>
				<td>Nome completo</td>
				<td><input class="form-control" type="text" name="nomecompleto"></td>
			</tr>
			<tr>
				<td>CPF(apenas números) </td>
				<td><input class="form-control" type="text" name="cpf"></td>
			</tr>
			<tr>
				<td>Endereço</td>
				<td><input class="form-control" type="text" name="endereco"></td>
			</tr>
			<tr>
				<td>Número</td>
				<td><input class="form-control" type="text" name="numero"></td>
			</tr>
			<tr>
				<td>Bairro</td>
				<td><input class="form-control" type="text" name="bairro"></td>
			</tr>
			<tr>
				<label>Estado </label>
				<select name="estado">
                <option value="">Selecione</option>
                <option value="AC">AC</option>
                <option value="AL">AL</option>
                <option value="AP">AP</option>
                <option value="AM">AM</option>
                <option value="BA">BA</option>
                <option value="CE">CE</option>
                <option value="ES">ES</option>
                <option value="GO">GO</option>
                <option value="MA">MA</option>
                <option value="MT">MT</option>
                <option value="MS">MS</option>
                <option value="MG">MG</option>
                <option value="PA">PA</option>
                <option value="PB">PB</option>
                <option value="PR">PR</option>
                <option value="PE">PE</option>
                <option value="PI">PI</option>
                <option value="RJ">RJ</option>
                <option value="RN">RN</option>
                <option value="RS">RS</option>
                <option value="RO">RO</option>
                <option value="RR">SC</option>
                <option value="SC">SC</option>
                <option value="SP">SP</option>
                <option value="SE">SE</option>
                <option value="TO">TO</option>
                <option value="DF">DF</option>

            </select>
			</tr>
			<tr>
				<td>Telefone</td>
				<td><input class="form-control" type="text" name="telefone"></td>
			</tr>
			
			<tr>
				<td><button class="btn btn-primary btn-lg">Cadastre-se</button></td>
			</tr>
		</table>
	</form>

<?php require_once("rodape.php"); ?>