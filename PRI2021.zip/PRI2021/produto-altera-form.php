
<?php
require_once("banco-categoria.php");
require_once("banco-produto.php");
$id = $_GET['id'];
$produto = buscaProduto($conexao, $id);
$categorias = listaCategoria($conexao);

session_start();
include_once("conecta.php");
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$result_produto = "SELECT * FROM produtos WHERE id = '$id'";
$resultado_produto = mysqli_query($conexao, $result_produto);
$row_produto = mysqli_fetch_assoc($resultado_produto);
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Alterar produto</title>      
    </head>
    <body>
        
        <h1>Alterar Produto</h1>
        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
        <form method="POST" action="altera-produto.php">
            <input type="hidden" name="id" value="<?php echo $row_produto['id']; ?>">
            
            <label>Nome: </label>
            <input type="text" name="nome" placeholder="Nome do produto" value="<?php echo $row_produto['nome']; ?>"><br><br>
            
            <label>Preço: </label>
            <input type="text" name="preco" placeholder="Digite o preço" value="<?php echo $row_produto['preco']; ?>"><br><br>

            <label>Descrição: </label>
            <input type="text" name="descricao" placeholder="Digite a descrição" value="<?php echo $row_produto['descricao']; ?>"><br><br>

            <label>Medida: </label>
            <input type="text" name="unidademedida" placeholder="Digite a unidade de medida" value="<?php echo $row_produto['unidademedida']; ?>"><br><br>
            <label>Imagem: </label>
            <input type="file" name="imagem" value="<?php header("Content-type: image/jpeg"); echo $produto['imageContent']?>"> <br>

            <tr>
                <td>Categoria</td>
                <td>
                    <select name="categoria_id" class="form-control">
                        <?php foreach ($categorias as $categoria) : 
                            $essaEhACategoria = $produto['categoria_id'] == $categoria['id'];
                            $selecao = $essaEhACategoria ? "selected='selected'" : "";
                            ?>
                            <option class="option" value="<?=$categoria['id']?>" <?=$selecao?>>
                                <?=$categoria['nome']?><br/>
                            </option>
                        <?php endforeach ?>
                    </select>
                </td>
            </tr>
            
            <input type="submit" value="Editar">
        </form>
    </body>
</html>