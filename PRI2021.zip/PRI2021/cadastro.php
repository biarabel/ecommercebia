<?php 
require_once("banco-usuario.php");
//require_once("logica-usuario.php");
?>
<?php

$email = $_POST["email"];
$senha = $_POST["senha"];
$confsenha = $_POST["confsenha"];
$nomeusuario = $_POST["nomeusuario"];
$nomecompleto = $_POST["nomecompleto"];
$cpf = $_POST["cpf"];
$endereco = $_POST["endereco"];
$numero = $_POST["numero"];
$bairro = $_POST["bairro"];
$estado = $_POST["estado"];
$telefone = $_POST["telefone"];


if($email == "" || $senha == "" || $confsenha == "" || $nomeusuario == "" || $nomecompleto == "" ||  $cpf == ""||$endereco == "" || $numero == "" || $bairro == "" || $estado == "" || $telefone == ""){
	$_SESSION["danger"] = "Prencha todos os dados.";
	header("Location: cadastro-form.php");
}else{
	cadastraUsuario($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $idcliente);
	$_SESSION["success"] = "Usuario cadastrado com sucesso.";
	header("Location: login.php");
}
die();
?>