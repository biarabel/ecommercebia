<?php
require_once("conecta.php");
function buscaUsuario($conexao, $email, $senha){
	$email = mysqli_real_escape_string($conexao, $email);
	$query = "select email, senha, nomeusuario, nomecompleto, cpf, endereco, numero, bairro, estado, telefone, idcliente from clientes where email = '{$email}' and senha = '{$senha}'";
	$resultado =  mysqli_query($conexao, $query);
	$usuario = mysqli_fetch_assoc($resultado);
	return $usuario;
}

function cadastraUsuario($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $idcliente)
{
	$email = mysqli_real_escape_string($conexao, $email);
	$senha = mysqli_real_escape_string($conexao, $senha);
	$confsenha = mysqli_real_escape_string($conexao, $confsenha);
	$nomeusuario = mysqli_real_escape_string($conexao, $nomeusuario);
	$nomecompleto = mysqli_real_escape_string($conexao, $nomecompleto);
	$cpf = mysqli_real_escape_string($conexao, $cpf);
	$endereco = mysqli_real_escape_string($conexao, $endereco);
	$numero = mysqli_real_escape_string($conexao, $numero);
	$bairro = mysqli_real_escape_string($conexao, $bairro);
	$estado = mysqli_real_escape_string($conexao, $estado);
	$telefone = mysqli_real_escape_string($conexao, $telefone);
	$idcliente = mysqli_real_escape_string($conexao, $idcliente);

	$query = "insert into clientes (email, senha, confsenha, nomeusuario, nomecompleto, cpf, endereco, numero, bairro, estado, telefone, idcliente) values ('{$email}','{$senha}','{$confsenha}','{$nomeusuario}','{$nomecompleto}','{$cpf}', '{$endereco}', '{$numero}', '{$bairro}', '{$estado}', '{$telefone}', '{$idcliente}')";
	$resultadoDaInsercao = mysqli_query($conexao, $query);
	return $resultadoDaInsercao;

}

function alteraCadastro($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $idcliente){
    $email = mysqli_real_escape_string($conexao, $email);
	$senha = mysqli_real_escape_string($conexao, $senha);
	$confsenha = mysqli_real_escape_string($conexao, $confsenha);
	$nomeusuario = mysqli_real_escape_string($conexao, $nomeusuario);
	$nomecompleto = mysqli_real_escape_string($conexao, $nomecompleto);
	$cpf = mysqli_real_escape_string($conexao, $cpf);
	$endereco = mysqli_real_escape_string($conexao, $endereco);
	$numero = mysqli_real_escape_string($conexao, $numero);
	$bairro = mysqli_real_escape_string($conexao, $bairro);
	$estado = mysqli_real_escape_string($conexao, $estado);
	$telefone = mysqli_real_escape_string($conexao, $telefone);
	$idcliente = mysqli_real_escape_string($conexao, $idcliente);
	 $query = "update clientes set nomeusuario='{$email}','{$senha}', '{$confsenha}', '
	 {$nomeusuario}','{$nomecompleto}','{$cpf}', '{$endereco}', '{$numero}', '{$bairro}', '{$estado}', '{$telefone}', '{$idcliente}' where idcliente='{$idcliente}'";
	 return mysqli_query($conexao, $query);
}

function removeCadastro($conexao, $ID){
	$query = "delete from clientes where idcliente={$idcliente}";
	return mysqli_query($conexao, $query);
}



