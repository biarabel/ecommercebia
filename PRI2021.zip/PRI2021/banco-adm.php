<?php
require_once("conecta.php");
function buscaAdm($conexao, $email, $senha){
	$email = mysqli_real_escape_string($conexao, $email);
	$query = "select email, senha, nomeusuario, nomecompleto, cpf, endereco, numero, bairro, estado, telefone, id from adm where email = '{$email}' and senha = '{$senha}'";
	$resultado =  mysqli_query($conexao, $query);
	$adm = mysqli_fetch_assoc($resultado);
	return $adm;
}

function cadastraAdm($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $id)
{
	$email = mysqli_real_escape_string($conexao, $email);
	$senha = mysqli_real_escape_string($conexao, $senha);
	$confsenha = mysqli_real_escape_string($conexao, $confsenha);
	$nomeusuario = mysqli_real_escape_string($conexao, $nomeusuario);
	$nomecompleto = mysqli_real_escape_string($conexao, $nomecompleto);
	$cpf = mysqli_real_escape_string($conexao, $cpf);
	$endereco = mysqli_real_escape_string($conexao, $endereco);
	$numero = mysqli_real_escape_string($conexao, $numero);
	$bairro = mysqli_real_escape_string($conexao, $bairro);
	$estado = mysqli_real_escape_string($conexao, $estado);
	$telefone = mysqli_real_escape_string($conexao, $telefone);
	$id = mysqli_real_escape_string($conexao, $id);

	$query = "insert into adm (email, senha, confsenha, nomeusuario, nomecompleto, cpf, endereco, numero, bairro, estado, telefone, id) values ('{$email}','{$senha}','{$confsenha}','{$nomeusuario}','{$nomecompleto}','{$cpf}', '{$endereco}', '{$numero}', '{$bairro}', '{$estado}', '{$telefone}', '{$id}')";
	$resultadoDaInsercao = mysqli_query($conexao, $query);
	return $resultadoDaInsercao;

}

function alteraCadastro($conexao, $email, $senha, $confsenha, $nomeusuario, $nomecompleto, $cpf, $endereco, $numero, $bairro, $estado, $telefone, $id){
    $email = mysqli_real_escape_string($conexao, $email);
	$senha = mysqli_real_escape_string($conexao, $senha);
	$confsenha = mysqli_real_escape_string($conexao, $confsenha);
	$nomeusuario = mysqli_real_escape_string($conexao, $nomeusuario);
	$nomecompleto = mysqli_real_escape_string($conexao, $nomecompleto);
	$cpf = mysqli_real_escape_string($conexao, $cpf);
	$endereco = mysqli_real_escape_string($conexao, $endereco);
	$numero = mysqli_real_escape_string($conexao, $numero);
	$bairro = mysqli_real_escape_string($conexao, $bairro);
	$estado = mysqli_real_escape_string($conexao, $estado);
	$telefone = mysqli_real_escape_string($conexao, $telefone);
	$id = mysqli_real_escape_string($conexao, $id);
	 $query = "update adm set nomeusuario='{$email}','{$senha}', '{$confsenha}', '
	 {$nomeusuario}','{$nomecompleto}','{$cpf}', '{$endereco}', '{$numero}', '{$bairro}', '{$estado}', '{$telefone}', '{$id}' where id='{$id}'";
	 return mysqli_query($conexao, $query);
}

function removeCadastro($conexao, $ID){
	$query = "delete from adm where id={$id}";
	return mysqli_query($conexao, $query);
}



