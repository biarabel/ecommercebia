<?php 

	require_once("banco-produto.php");
?>

<?php

$id = $_POST["id"];
$nome = $_POST["nome"];
$preco = $_POST["preco"];
$descricao = $_POST["descricao"];
$categoria_id = $_POST["categoria_id"];
$unidademedida = $_POST["unidademedida"];
$imagem = $_POST["imagem"];

if(alteraProduto($conexao, $id, $nome, $preco, $descricao, $categoria_id, $unidademedida, $imagem)){ ?>
	<p>Produto <?= $nome; ?> foi alterado com sucesso.</p>
<?php 
}else{ 
	$msg = mysqli_error($conexao);
?>
	<p>Produto <?= $nome; ?>, não foi alterado: <?= $msg ?></p>
<?php
}
?>

<a href="produto-lista.php">Voltar</a>
<?php require_once("rodape.php"); ?>