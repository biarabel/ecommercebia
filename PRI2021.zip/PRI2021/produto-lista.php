<?php 
	require_once("banco-produto.php");

?>

<head>
    
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">


</head>

<table class="table table-bordered"> 

<?php
$produtos = listaProdutos($conexao);
foreach ($produtos as $produto) :
?>
<div class="container">
<table>

            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Descrição</th>
                    <th>Categoria</th>
                    <th>Peso</th>
                    <th>Imagem</th>


                </tr>
            </thead>

        <div>
    <tr>
        <td><?= $produto['nome'] ?></td>
        <td><?= $produto['preco'] ?></td>
        <td><?= substr($produto['descricao'], 0, 40) ?></td>
        <td><?= $produto['categoria_nome'] ?></td>
        <td><?= $produto['unidademedida'] ?></td>
        <td><img src="<?=$produto['imagem']?>"> <?=$produto['imagem']?> </td>
      
           <td><a class="btn btn-primary btn-lg" href="produto-altera-form.php?id=<?=$produto['id']?>">Alterar</a>
           <form action="confirma.php?id=<?=$produto['id']?>" method="POST"  ></br>
                    <input  type="hidden" name="id" value="<?= $produto['id']?>">
                    <button tabindex="0" class=" fas fa-trash-alt text-danger btn btn-link  ml-auto titulo" data-toggle="popover"  data-placement="right" data-trigger="focus" title="Excluir" type="Submit" id="btn-excluir"> Remover</button>
                </form>
          
    
        </div>
    </tr>
</tbody>

	
<?php
endforeach
?>

</table>

        <a href="menuadm.php">Voltar ao menu</a>

    