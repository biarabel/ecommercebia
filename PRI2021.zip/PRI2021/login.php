<?php session_start(); ?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Montagna Chocolatier Login</title>
    </head>
    <body>
        <center>
            <h1>Login</h1>
            <form action="validacao.php" method="post">
                <label><strong>Usuário </strong><input type="email" name="email"></label>
                <br><br>
                <label><strong>Senha </strong><input type="password" name="senha"></label>
                <br><br>
                <label><input type="submit" name="login" value="LOGIN"></label>
            </form>
            <br><br>
            <a href="">Esqueci minha senha</a> | <a href="cadastro-form.php">Crie sua Conta</a> | <a href="loginadm.php"> Login administrador</a>
            <p class="text-center text-danger">
                <?php
                    if(isset($_SESSION['errologin']))
                    {
                        echo $_SESSION['errologin'];
                        unset($_SESSION['errologin']);
                    }
                ?>
            </p>
            <p class="text-center text-success">
                <?php 
                    if(isset($_SESSION['deslogado']))
                    {
                        echo $_SESSION['deslogado'];
                        unset($_SESSION['deslogado']);
                    }
                ?>
            </p>
        </center>
    </body>
</html>