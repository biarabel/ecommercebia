<?php
    session_start();
    include_once("conecta.php");
    if((isset ($_POST['email'])) && (isset ($_POST['senha'])))
    {
        $email = mysqli_real_escape_string($conexao, $_POST['email']);
        $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
        //$senha = md5($senha);
        $pesqbd = "SELECT * FROM adm WHERE email = '$email' && senha = '$senha' LIMIT 1";
        $resultado_adm = mysqli_query($conexao, $pesqbd);
        $resultado = mysqli_fetch_array($resultado_adm);
        
        if(isset($resultado))
        {
            $_SESSION['id'] = $resultado['id'];
            $_SESSION['nomeusuario'] = $resultado['nomeusuario'];
            $_SESSION['email'] = $resultado['email'];

            header("Location: menuadm.php");
        }
        else
        {   
            $_SESSION['errologin'] = "Usuário ou senha inválido";
            header("Location: login.php");
        }
    }
    else
    {
        $_SESSION['errologin'] = "Usuário ou senha inválido.";
        header("Location: login.php");
    }
?>